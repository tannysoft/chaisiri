<?php
/**
 * Copyright (C) 2014-2018 ServMask Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * ███████╗███████╗██████╗ ██╗   ██╗███╗   ███╗ █████╗ ███████╗██╗  ██╗
 * ██╔════╝██╔════╝██╔══██╗██║   ██║████╗ ████║██╔══██╗██╔════╝██║ ██╔╝
 * ███████╗█████╗  ██████╔╝██║   ██║██╔████╔██║███████║███████╗█████╔╝
 * ╚════██║██╔══╝  ██╔══██╗╚██╗ ██╔╝██║╚██╔╝██║██╔══██║╚════██║██╔═██╗
 * ███████║███████╗██║  ██║ ╚████╔╝ ██║ ╚═╝ ██║██║  ██║███████║██║  ██╗
 * ╚══════╝╚══════╝╚═╝  ╚═╝  ╚═══╝  ╚═╝     ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
 */

class Ai1wmle_Import_Download {

	public static function execute( $params, $client = null ) {

		// Set completed flag
		$params['completed'] = false;

		// Set URL client
		if ( empty( $client ) ) {
			$client = new Ai1wmle_URL_Client;
		}

		// Set base URL
		$client->set_base_url( $params['file_url'] );

		// Get archive file
		$archive = fopen( ai1wm_archive_path( $params ), 'ab' );

		if ( ! empty( $params['total_bytes'] ) ) {

			// Set start bytes
			if ( ! isset( $params['start_bytes'] ) ) {
				$params['start_bytes'] = 0;
			}

			// Set end bytes
			if ( ! isset( $params['end_bytes'] ) ) {
				$params['end_bytes'] = AI1WMLE_FILE_CHUNK_SIZE;
			}

			// Set retry
			if ( ! isset( $params['retry'] ) ) {
				$params['retry'] = 0;
			}

			try {

				// Increase number of retries
				$params['retry'] += 1;

				// Download file in chunks
				$client->download_file_chunk( $archive, $params );

			} catch ( Ai1wmle_Connect_Exception $e ) {
				// Retry 3 times
				if ( $params['retry'] <= 3 ) {
					return $params;
				}

				throw $e;
			}

			// Unset retry counter
			unset( $params['retry'] );

			// Calculate percent
			$percent = (int) ( ( $params['start_bytes'] / $params['total_bytes'] ) * 100 );

			// Set progress
			Ai1wm_Status::progress( $percent );

			// Completed?
			if ( $params['total_bytes'] == $params['start_bytes'] ) {

				// Unset total bytes
				unset( $params['total_bytes'] );

				// Unset start bytes
				unset( $params['start_bytes'] );

				// Unset end bytes
				unset( $params['end_bytes'] );

				// Unset completed flag
				unset( $params['completed'] );

			}
		} else {

			// Try to download the file in one request
			$client->download_file( $archive, $params );

			// Unset completed flag
			unset( $params['completed'] );

		}

		// Closing the archive
		fclose( $archive );

		return $params;
	}
}
